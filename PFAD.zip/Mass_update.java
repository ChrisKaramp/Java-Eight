
import java.io.IOException;

public class Mass_update {
    
    public static void write_sorted_data_into_file(String datafilepath) throws IOException {
        // fetch all data from file, sort and re-write them
        Get_data_from_file.fetch_all_data(Constants.DATA_FILE_PATH);
        System.out.println(Get_data_from_file.data_file_records);
    }

}
