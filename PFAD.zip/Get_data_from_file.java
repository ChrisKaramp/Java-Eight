import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Get_data_from_file {

    public static List<List<String>> data_file_records = new ArrayList<>();

    public static void fetch_all_data(String datafilepath) throws IOException {

        try (BufferedReader data_file_BufferedReader = new BufferedReader(new FileReader(datafilepath))) {
            String data_file_line;
            while ((data_file_line = data_file_BufferedReader.readLine()) != null) {
                String[] year_values = data_file_line.split(Constants.COMMA_DELIMITER);
                data_file_records.add(Arrays.asList(year_values));
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the data file.");
            throw e;
        }

        // print before sorting
        System.out.println(data_file_records);
        // sort by year descending
        data_file_records.sort((year2, year1) -> year1.get(0).compareTo(year2.get(0)));

        // print after sorting
        //
        for (List<String> data_file_record : data_file_records) {
           System.out.println(data_file_record);
        }
        
    }

}