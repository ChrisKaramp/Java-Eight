import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Add_year {

    public static void add_year_into_data_file(String datafilepath, String year_entered) throws IOException {
        
    // form a new year record with zero values
    // add year, then add as many zeros as values (fields)
    List<String> new_year_record_araylist = new ArrayList<>();
    new_year_record_araylist.add(year_entered);
    for (int i = 1; i < Constants.DATA_FILE_HEADERS.length; i++) {
        new_year_record_araylist.add("0");
    }
    // set and add delimiter in record
    String new_year_record = new_year_record_araylist.stream().collect(Collectors.joining(Constants.COMMA_DELIMITER));

    // add new year record to data file
    Add_record_to_file.append_record(datafilepath, new_year_record);

    // Sort all data file by doing a mass update
    Mass_update.write_sorted_data_into_file(datafilepath);
    }
}
