import java.io.IOException;
import javax.swing.JOptionPane;

public class Pfad {
    public static void main(String[] args) throws IOException {

        // check if data file exists, then get all data in array, else create and initialize it
        if ( Build_data_file.create_data_file(Constants.DATA_FILE_PATH).equalsIgnoreCase("created") ) {
            Build_data_file.initialize_data_file(Constants.DATA_FILE_PATH);
            System.out.println("Data file initialized successfully.");
        } else if ( Build_data_file.create_data_file(Constants.DATA_FILE_PATH).equalsIgnoreCase("error") ) {
            JOptionPane.showMessageDialog
                (null,
                "Could not create data file. Please check file path and permissions.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            System.out.println("An error occurred while creating data file. Exit code: 1.");
            System.exit(1);
        }

        // create budget origin window, dimensions same as screen, defined in Constants class
        Budget_origin_window_model budgetOriginWindow = new Budget_origin_window_model(Constants.FRAME_WIDTH, Constants.FRAME_HEIGHT, Constants.DATA_FILE_PATH);
        budgetOriginWindow.setTitle("Προέλευση Κρατικού Προϋπολογισμού");
    }
}
